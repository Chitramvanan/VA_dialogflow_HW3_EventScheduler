// See https://github.com/dialogflow/dialogflow-fulfillment-nodejs
// for Dialogflow fulfillment library docs, samples, and to report issues
'use strict';

//const {dialogflow} = require('actions-on-google');
const functions = require('firebase-functions');
const {WebhookClient} = require('dialogflow-fulfillment');
const {Card, Suggestion} = require('dialogflow-fulfillment');

process.env.DEBUG = 'dialogflow:debug'; // enables lib debugging statements
 
exports.dialogflowFirebaseFulfillment = functions.https.onRequest((request, response) => {
  const agent = new WebhookClient({ request, response });
  console.log('Dialogflow Request headers: ' + JSON.stringify(request.headers));
  console.log('Dialogflow Request body: ' + JSON.stringify(request.body));
 


//const app = dialogflow({debug: true});

 
  
  function welcome(agent) {
    agent.add(`Welcome to my agent!`);
  }
 
  function fallback(agent) {
    agent.add(`I didn't understand`);
    agent.add(`I'm sorry, can you try again?`);
  }
  
 var busyDatesTimes = ['2022-10-01T10:00:00-07:00','2022-11-01T10:00:00-07:00','2022-09-01T11:00:00-07:00','2022-12-01T10:00:00-07:00'];

  
 function scheduleEvent(agent) {
     const [eventName, date_time] = [agent.parameters.EventName, agent.parameters.date_time.date_time];  	
	 if (busyDatesTimes.some(row => JSON.stringify(row) === JSON.stringify(date_time))){
          agent.add(`Sorry, Your calendar is booked for this slot, please try another slot`);
    }
    else {
         //Code to add event to the list of events
         busyDatesTimes.push(date_time);
         agent.add(`Your ${eventName} appointment for ${date_time} is scheduled, have a good day!`);
      	 
    }
	    
 }
  
  function deleteEvent(agent) {
      const [eventName_1, date_time_1] = [agent.parameters.EventName, agent.parameters.date_time.date_time];  	
	  if (busyDatesTimes.some(row => JSON.stringify(row) === JSON.stringify(date_time_1))){
               //Code to remove the event from the list of events
               for (var i = 0; i < busyDatesTimes.length; i++) {
                  if (busyDatesTimes[i] === date_time_1) {
                  busyDatesTimes.splice(i, 1);
                  }
              }
           agent.add(`Your ${eventName_1} appointment for ${date_time_1} is canceled, have a good day!`);
          }
       else {
               agent.add(`Sorry, there is no such event in your calendar!`);
          }       
 }

  function lookupCalendar(agent) {
     const date_time_2 = agent.parameters.date_time[0].date_time;  	
	if (busyDatesTimes.some(row => JSON.stringify(row) === JSON.stringify(date_time_2))){
          agent.add(`Sorry, Your calendar is already booked for this slot.`);
    }
    else {
         agent.add(`Yes, your calendar is free at this time!`);
      	 
    }
}

  
  // // Uncomment and edit to make your own intent handler
  // // uncomment `intentMap.set('your intent name here', yourFunctionHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function yourFunctionHandler(agent) {
  //   agent.add(`This message is from Dialogflow's Cloud Functions for Firebase editor!`);
  //   agent.add(new Card({
  //       title: `Title: this is a card title`,
  //       imageUrl: 'https://developers.google.com/actions/images/badges/XPM_BADGING_GoogleAssistant_VER.png',
  //       text: `This is the body text of a card.  You can even use line\n  breaks and emoji! 💁`,
  //       buttonText: 'This is a button',
  //       buttonUrl: 'https://assistant.google.com/'
  //     })
  //   );
  //   agent.add(new Suggestion(`Quick Reply`));
  //   agent.add(new Suggestion(`Suggestion`));
  //   agent.setContext({ name: 'weather', lifespan: 2, parameters: { city: 'Rome' }});
  // }

  // // Uncomment and edit to make your own Google Assistant intent handler
  // // uncomment `intentMap.set('your intent name here', googleAssistantHandler);`
  // // below to get this function to be run when a Dialogflow intent is matched
  // function googleAssistantHandler(agent) {
  //   let conv = agent.conv(); // Get Actions on Google library conv instance
  //   conv.ask('Hello from the Actions on Google client library!') // Use Actions on Google library
  //   agent.add(conv); // Add Actions on Google library responses to your agent's response
  // }
  // // See https://github.com/dialogflow/fulfillment-actions-library-nodejs
  // // for a complete Dialogflow fulfillment library Actions on Google client library v2 integration sample

  // Run the proper function handler based on the matched Dialogflow intent name
  let intentMap = new Map();
  intentMap.set('Default Welcome Intent', welcome);
  intentMap.set('Default Fallback Intent', fallback);
  intentMap.set('ScheduleEvent', scheduleEvent);
  intentMap.set('DeleteEvent', deleteEvent);
  intentMap.set('LookupCalendar', lookupCalendar);
  // intentMap.set('your intent name here', yourFunctionHandler);
  // intentMap.set('your intent name here', googleAssistantHandler);
  agent.handleRequest(intentMap);
});
